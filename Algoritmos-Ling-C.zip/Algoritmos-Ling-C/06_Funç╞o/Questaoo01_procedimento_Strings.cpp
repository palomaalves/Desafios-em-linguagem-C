#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

//Escreva um programa que receba o nome e o sobrenome do usu�rio (armazene em strings).
//Crie um procedimento chamado void imprimir()que imprime o nome e sobrenome do usu�rio.

void imprimir(char a[20], char b[20]){
	
	printf("\nSeu nome completo �: %s %s", a, b);
}

int main() {
	setlocale(LC_ALL, "");
	char nome[20];
	char sobrenome[20];
	printf("Digite o nome: ");
	gets(nome);
	printf("Digite o sobrenome: ");
	gets(sobrenome);
	
	imprimir(nome, sobrenome);
	
	return 0;
}




