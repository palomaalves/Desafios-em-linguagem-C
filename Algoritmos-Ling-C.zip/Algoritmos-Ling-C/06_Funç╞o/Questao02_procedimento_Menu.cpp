#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>


//Escreva um procedimento void menu() que represente o menu de uma calculadora mostrando ao usu�rio as op��es a serem escolhidas.
/*Modifique o Exerc�cio 2 para criar uma calculadora.
�O programa deve executar menu() e mostrar as op��es ao usu�rio.
�O programa deve pedir para o usu�rio entrar com dois n�meros reais.
�Por fim, o programa deve chamar a fun��o escolhida pelo usu�rio:
�floatsomar(floata, floatb), floatsubtrair(floata, floatb), floatmultiplicar(floata, floatb) ou floatdividir(floata, floatb).
�O retorno da fun��o deve ser impresso na fun��o main().*/


//implementa��o do procedimento
void menu(){
	int opcao;
	float a, b, r;
	printf("Selecione a op��o:\n");
	printf("1-Adi��o\n");
	printf("2-Subtra��o\n");
	printf("3-Multiplica��o\n");
	printf("4-Divis�o\n");
	printf("0-Sair\n");
	scanf("%d",&opcao);
	
	switch(opcao){
		case 1:
			printf("Digite o primeiro valor: ");
			scanf("%f",&a);
			fflush(stdin);
			printf("Digite o segundo valor: ");
			scanf("%f",&b);
			fflush(stdin);
			r=a+b;
			printf("\nO resultado final �: %.2f",r);
			break;
		case 2:
			printf("Digite o primeiro valor: ");
			scanf("%f",&a);
			fflush(stdin);
			printf("Digite o segundo valor: ");
			scanf("%f",&b);
			fflush(stdin);
			r=a-b;
			printf("\nO resultado final �: %.2f",r);
			break;
		case 3:
			printf("Digite o primeiro valor: ");
			scanf("%f",&a);
			fflush(stdin);
			printf("Digite o segundo valor: ");
			scanf("%f",&b);
			fflush(stdin);
			r=a*b;
			printf("\nO resultado final �: %.2f",r);
			break;
		case 4:
			printf("Digite o primeiro valor: ");
			scanf("%f",&a);
			fflush(stdin);
			printf("Digite o segundo valor: ");
			scanf("%f",&b);
			fflush(stdin);
			if(b!=0)
			{
				r=a/b;	
				printf("\nO resultado final �: %.2f",r);
			}
			break;
		case 0:
			break;
		default:
			printf("\nOp��o inv�lida");
			break;
	}
}


int main(){
	
	setlocale(LC_ALL, "");
	int opcao;
	
	menu();
	
	while(opcao != 0)
	{
		scanf("%d", &opcao);
	}
	
	return 0;
}
