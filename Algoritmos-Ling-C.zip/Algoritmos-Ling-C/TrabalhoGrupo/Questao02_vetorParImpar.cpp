#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 02
	Estenda o Exerc�cio 1 para, a partir do vetor NUMEROS completamente preenchido, 
	escrever os vetores VP (que ser� um vetor de n�meros pares) e VI (que ser� um vetor de n�meros �mpares).*/
	
int main()
{
	setlocale(LC_ALL, "");
	
    int numeros[10],i, VP[10], VI[10], x=0,y=0;
	for(i= 0; i<=9; i++)
	{
		printf("Digite %d n�mero: ", i+1);
		scanf("%d", &numeros[i]);
	}
	printf("\nN�meros escolhidos:");
	for(i= 0; i<=9; i++)
	{
		printf(" %d  ", numeros[i]);
	}
	
	int maior = numeros[0];
	for (i=1; i<10; i++)
	{
		if (maior < numeros[i])
		{
			maior = numeros[i];
		}
			
	}
	
	int menor = numeros[0];
	for (i=1; i<10; i++)
	{
		if (menor > numeros[i])
		{
			menor = numeros[i];
		}
	}
	printf("\n\nO maior n�mero digitado foi: %d \n", maior);
	printf("\nO menor n�mero digitado foi: %d \n ", menor);
	
	for (i=1; i<10; i++)
    {
        if(numeros[i]%2 == 0)//verifica��o se o n�mero � par//
        {
            VP[x]=numeros[i];//Armazenamento dos numeros pares no vetor par//
            x++; //incremento do �ndice do vetor par//
        }    
        else //se o numeto inteiro n�o � par, � �mpar!//
        {
            VI[y]=numeros[i];//Armazenamento dos numeros �mpares no vetor �mpar//
            y++; //incremento do �ndice do vetor �mpar//
        }   
     } 

	
    //impress�o do vetor par//
	printf("\n VP: ");
    for (i=0; i<x; i++)
    {
		printf("%d ",VP[i]);
	}
          
	printf("\n");
	
    //impress�o do vetor �mpar//
	printf("\n VI: ");
    for (i=0; i<y; i++)
    {
    	printf("%d ",VI[i]);
	}
         
 
return 0;
}	
			
