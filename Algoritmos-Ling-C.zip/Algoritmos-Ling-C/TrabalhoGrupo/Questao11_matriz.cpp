#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 11
Fa�a um programa em C que l� um n�mero inteiro e uma matriz 50 x 100 de n�meros inteiros, 
e exibe a soma dos elementos da matriz maiores que o n�mero lido..*/

int main(void)
{
    setlocale(LC_ALL, "");
	
	// Rotina para gerar a matriz com n�meros aleat�rios
	int totalLinhas = 50;
	int totalColunas = 100;
	int rangeNumerosAleatorios = 100;
	
	int i, j,matriz[totalLinhas][totalColunas];
	
	printf("Matriz %d x %d com n�meros aleat�rios de 0 a %d gerada!\n", totalLinhas, totalColunas, rangeNumerosAleatorios - 1);
	for(i = 0; i < totalLinhas;i++) {
    	for(j = 0; j < totalColunas;j++) {
    		matriz[i][j]= rand()%rangeNumerosAleatorios;
    		printf("%d ", matriz[i][j]);
    	}
    	printf("\n");
    }
    // FIM DA ROTINA 
    
    // Rotina de entrada de dados
    int numeroDigitado;
    
    printf("\nDigite um n�mero: ");
	scanf("%d", &numeroDigitado);
	// FIM DA ROTINA 
	
	// Rotina para identificar n�meros da matriz maiores que o n�mero digitado pelo usu�rio
	int soma = 0;
	
		for(i = 0; i < totalLinhas;i++) {
    		for(j = 0; j < totalColunas;j++) {
    			if (matriz[i][j] > numeroDigitado){
    				soma += matriz[i][j];
				} 
    		}
    	}
    // FIM DA ROTINA 
    	
    printf("Resultado da soma dos n�meros maiores que %d � %d.", numeroDigitado,soma);
    
  return 0;
}
