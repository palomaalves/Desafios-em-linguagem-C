#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <math.h>

//Disciplina de T�cnicas de Programa��o
//Professor Renan Alencar
//Grupo 01:
//Alequissandra Rayane Farias Santos Silva - 202000574
//Beatriz Lira Martins - 2020002049
//Matheus Barros Cris�stomo - 202058447
//Paloma Corr�a Alves - 202000716
//Thulio Mateus de Oliveira Queiroz - 202003804

/*Quest�o 09
	Fa�a um programa em C que l� n�meros inteiros at� que o que n�mero zero seja informado
    e, para cada n�mero lido, chama uma fun��o que recebe o n�mero por par�metro e retorna um valor 
    l�gico para indicar se o n�mero recebido � divis�vel por 3 ou n�o. 
    A frase "<n�mero lido> � divis�vel por 3" deve ser exibida para o usu�rio no algoritmo principal, caso o n�mero lido 
    seja divis�vel por 3. 
    A frase "<n�mero lido> n�o � divis�vel por 3" deve ser exibida para o usu�rio 
    no algoritmo principal, caso o n�mero lido n�o seja divis�vel por 3. 
	Lembrando que um n�mero � divis�vel por tr�s se o resto da divis�o inteira do n�mero por tr�s for zero. */


//Divis�vel Por 3
void divisivel(int n)
{
	if(n % 3 == 0)
	{
		printf("%d � divis�vel por 3\n", n);
	}else
	{
		printf("%d n�o � divis�vel por 3\n", n);
	}
}


//Fun��o Principal 
int main()
{
	setlocale(LC_ALL, "");
	int valor, contador;
	
	do
	{
	printf("\nDigite um valor: ");
	scanf("%d", &valor);
	divisivel(valor);
		if(valor == 0){
			contador = 0;
			break;
		}else{
			contador = 1;
		}
	}while(contador == 1);
	return 0;
}
