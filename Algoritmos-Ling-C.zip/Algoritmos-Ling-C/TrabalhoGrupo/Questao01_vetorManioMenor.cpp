#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 01 
Leia um vetor chamado NUMEROS de 10 n�meros inteiros e exiba qual o maior e o menor n�mero desse vetor.*/


int main()
{
	setlocale(LC_ALL, "");
	
    int numeros[10],i;
	for(i= 0; i<=9; i++)
	{
		printf("Digite %d n�mero: ", i+1);
		scanf("%d", &numeros[i]);
	}
	printf("\nN�meros escolhidos:");
	for(i= 0; i<=9; i++)
	{
		printf(" %d  ", numeros[i]);
	}
	
	int maior = numeros[0];
	for (i=1; i<10; i++)
	{
		if (maior < numeros[i])
		{
			maior = numeros[i];
		}
	}
	
	int menor = numeros[0];
	for (i=1; i<10; i++)
	{
		if (menor > numeros[i])
		{
			menor = numeros[i];
		}
	}
	printf("\n\nO maior n�mero digitado foi: %d", maior);
	printf("\nO menor numero digitado foi: %d ", menor);
		
	
return 0;
}

