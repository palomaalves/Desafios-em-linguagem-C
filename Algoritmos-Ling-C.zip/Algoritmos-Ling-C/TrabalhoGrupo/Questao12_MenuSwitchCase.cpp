#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 12
Uma escola deseja implementar um sistema que possua um menu com as seguintes op��es:
a. Caso seja escolhida a op��o 1 o sistema deve: Ler 2 notas e nomes de 5 alunos e armazenar em um vetor;
b. Caso seja escolhida a op��o 2 o sistema deve: Exibir m�dia geral de todos os alunos;
c. Caso seja escolhida a op��o 3 o sistema deve: Exibir uma lista com o nome e as notas de todos os alunos;
d. Caso seja escolhida a op��o 4 o sistema deve: Exibir uma lista com o nome e as m�dias de todos os
alunos; se a m�dia for maior igual 7 mostrar na tela �Aprovado�, sen�o imprimir na tela �Reprovado�.
*/

int main ()
{
	setlocale(LC_ALL, "");
	 
	int  i, opcao, qtdeAlunos=5; 
	float media[5], n1[5], n2[5], mediaGeral=0;
    char aluno[5][20];

	printf("=============== CADASTRO ===============\n");
    for(i=0; i<qtdeAlunos; i++)
	{
		printf("\nDigite o Nome do %d aluno: ", i+1);
		scanf("%s", aluno[i]);
		printf("\nDigite a Primeira Nota do %d aluno: ", i+1);
		scanf("%f", &n1[i]);
		printf("\nDigite a Segunda Nota do %d aluno: ", i+1);
		scanf("%f", &n2[i]);		
	};
	
	for(i=0; i<4; i++)
	{
		printf("\n\n=============== Digite a Op��o que deseja ===============\n");
	    printf( "\n-> (1) para armazenar 02 notas e os nomes de 05 alunos em um vetor.");
	    printf( "\n-> (2) para exibir a m�dia geral dos alunos.");
	    printf( "\n-> (3) para exibir os nomes e as notas dos alunos.");
	    printf( "\n-> (4) para exibir as m�dias e status de aprova��o dos alunos.\n");
	    printf( "\n-> Selecione a opc�o: ");
		scanf("%d", &opcao);
		
		switch (opcao)
		{
	        case 1 : 
			   for(i=0; i<qtdeAlunos; i++)
				{
					printf("\nDados armazenados em Vetores: %s,  %.1f , %.1f ", aluno[i], n1[i], n2[i]);
				}
	        break;
	
	        case 2 :  
				for(i=0; i<qtdeAlunos; i++)
				{ 
				media[i]=((n1[i] + n2[i])/2);
				mediaGeral=(mediaGeral+media[i]);
				}
				mediaGeral=((mediaGeral+media[i])/qtdeAlunos);
	        	printf("\nA media geral de todos os alunos �: %.2f ", mediaGeral);
	        break;
	
	        case 3 : 		    
	        	for(i=0; i<qtdeAlunos; i++)
				{ 
					printf("\nO aluno(a) %s possui as notas %.1f e %.1f \n", aluno[i], n1[i], n2[i]);
				}
			break;
	
	        case 4 :  
	        	for(i=0; i<qtdeAlunos; i++)
				{ 
					media[i]=((n1[i] + n2[i])/2);
					printf("\nO aluno(a) %s possui a media: %.2f\n" , aluno[i], media[i]);
					if(media[i]>=7)
					{printf("\nAprovado\n");}
					else{printf("\nReprovado\n");}
			   	}
	        break; 
			default: 
				printf("\nOp��o Inv�lida!");
	  		break;
    	}
	}	
		return 0 ;
}
