#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 03
Estenda o Exerc�cio 1 para, a partir do vetor NUMEROS, gerar o vetor OPOSTO, que corresponde ao vetor NUMEROS ao contr�rio. 
Exemplo, se o n�mero � 12 no vetor deve estar 21.*/

int main(void)
{
    setlocale(LC_ALL, "");
	
    int numeros[10],i, oposto[10];
   
	for(i= 0; i<=9; i++)
	{
		// Entrada de dados
		printf("Digite o n�mero do item %d: ", i+1);
		scanf("%d", &numeros[i]);
		
		// Rotina para inverter os algarismos do n�mero digitado pelo usu�rio
		int r = 0;
		int numeroTemp = numeros[i];
		while (numeroTemp != 0) { 
			r = r * 10; 
			r = r + numeroTemp%10; 
			numeroTemp = numeroTemp/10; 
		}
		oposto[i]=r;
		// FIM DA ROTINA de invers�o dos algarismos
	}
	
	printf("\nVetor Oposto:\n", oposto[i]);

	// Exibe os itens do vetor oposto com os n�meros ao contr�rio na tela
	for (i = 0; i < 10; i++){
		printf("%d\n", oposto[i]);
	}
    
  return 0;
}
