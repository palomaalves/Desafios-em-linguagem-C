#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <math.h>

//Disciplina de T�cnicas de Programa��o
//Professor Renan Alencar
//Grupo 01:
//Alequissandra Rayane Farias Santos Silva - 202000574
//Beatriz Lira Martins - 2020002049
//Matheus Barros Cris�stomo - 202058447
//Paloma Corr�a Alves - 202000716
//Thulio Mateus de Oliveira Queiroz - 202003804

/*Quest�o 07 
Um nadador dos 800 metros estilo peito est� se preparando para uma competi��o e 
deseja fazer uma an�lise de seus resultados. Para isso, em seus treinos, 
ele anotou 20 tomadas de tempo a cada vez que completava 800 metros. 
Fa�a um programa em C que armazene, em um vetor, essas 20 tomadas de tempo, calcule e imprima:
a) A m�dia de tempo em que ele percorreu os 800m
b) O pior (maior) e melhor tempo (menor) em que ele percorreu os 800m
*/

int main()
{

	setlocale(LC_ALL, "");
	
	int totalTomadasTempo = 20;
	
	float tomadaTempo[totalTomadasTempo];
	float somaTomadasTempo = 0;
	float melhorTempo = 0;
	float piorTempo = 0;
	
	int i;

	for (i = 0; i < totalTomadasTempo; i++)
	{
		printf("Informe a tomada de tempo %d (em segundos): ", i + 1);
	    scanf("%f",&tomadaTempo[i]);
	    
	    //Rotina para checar pior tempo
	    if (i == 0){
			piorTempo = tomadaTempo[i];
		}else{
			if (tomadaTempo[i] > piorTempo){
	    		piorTempo = tomadaTempo[i];
			}
		}
		
	    //Rotina para checar melhor tempo
	    if (i == 0){
			melhorTempo = tomadaTempo[i];
		}else{
			if (tomadaTempo[i] < melhorTempo){
	    		melhorTempo = tomadaTempo[i];
			}
		}
		somaTomadasTempo += tomadaTempo[i];	    
	    
	    printf("\n");
	}
	
	printf("\n\nA m�dia de tempo foi de %.2f segundos.", float(somaTomadasTempo/totalTomadasTempo));
	printf("\n\nO melhor tempo foi de %.2f segundos.", melhorTempo);
	printf("\n\nO pior tempo foi de %.2f segundos.", piorTempo);
	
	return 0;

}
