#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>


/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 08
Fa�a um programa em C que leia o nome, idade e sexo de 20 pessoas e:
a) Imprima o nome delas,
b) Calcule e imprima o nome do homem mais velho,
c) Calcule e imprima a m�dia da idade das mulheres 
*/


int main()
{
	setlocale(LC_ALL, "");
	
	int totalPessoas = 5;
	int idade[totalPessoas], sexo[totalPessoas], idadeHomemMaisVelho=0, indiceHomemMaisVelho;
	char nome[totalPessoas][20];
	int i, qtdeMulheres=0, somaIdadeMulheres=0;

	for (i = 0; i < totalPessoas; i++)
	{
		printf("Digite o nome da pessoa %d: ", i+1);
		scanf("%s", nome[i]);
		printf("Informe o sexo. \n(1) MASCULINO ou (2) FEMININO): ");
		scanf("%d", &sexo[i]);
		printf("Digite a idade: ");
	    scanf("%d",&idade[i]);
	    printf("\n");
	}
	printf("\n");
	
//a) Imprima o nome delas:
	
	printf("\nOs nomes s�o: ");
	for ( i = 0; i < totalPessoas; i++)
	{
		printf("\n%s", nome[i]);
	}

//b) Calcule e imprima o nome do homem mais velho:
	
	for ( i = 0; i < totalPessoas; i++)
	{
		if(sexo[i]==1 & (idadeHomemMaisVelho<idade[i]))
		{
			idadeHomemMaisVelho=idade[i];
			indiceHomemMaisVelho = i;
		}else if (sexo[i]==2){
			qtdeMulheres += 1;
			somaIdadeMulheres += idade[i];
		}
	}
	
	printf("\n\nO homem mais velho � %s com %d anos.", nome[indiceHomemMaisVelho], idadeHomemMaisVelho);
	printf("\n\nA quantidade total de mulheres � %d e a m�dia de idade delas � de %d anos.", qtdeMulheres, somaIdadeMulheres / qtdeMulheres);
	
	return 0;

}
