#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/
//Quest�o 05
//Criar um programa em C que armazene nome, duas notas de 5 alunos e imprima uma listagem contendo nome, as duas notas e a m�dia de cada aluno.


int main( )
{
	
	setlocale(LC_ALL, "");
	char nomes[5][21];
	int i;
	float nota1[5];
	float nota2[5];
 	
	for (i = 0; i < 5; i++)
	{
		printf("Digite o nome do aluno %d: ", i+1);
		scanf("%s", nomes[i]);
		printf("Nota 1: ");
	    scanf("%f",&nota1[i]);
	    printf("Nota 2: ");
	    scanf("%f",&nota2[i]);
	    printf("\n");
	}
	printf("\n");
	
	for (i = 0; i < 5; i++)
	{
	printf("Nome do Aluno: %s\n", nomes[i]);
	printf("Nota 01� %.1f\n", nota1[i]);
	printf("Nota 02- %.1f\n", nota2[i]);
	printf("M�dia: %.1f\n", (nota1[i]+nota2[i])/2);
	printf("\n\n");
	}
	return 0;
}
