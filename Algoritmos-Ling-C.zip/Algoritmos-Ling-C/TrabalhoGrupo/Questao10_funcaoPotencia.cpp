#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <math.h>

//Disciplina de T�cnicas de Programa��o
//Professor Renan Alencar
//Grupo 01:
//Alequissandra Rayane Farias Santos Silva - 202000574
//Beatriz Lira Martins - 2020002049
//Matheus Barros Cris�stomo - 202058447
//Paloma Corr�a Alves - 202000716
//Thulio Mateus de Oliveira Queiroz - 202003804

/*Quest�o 10 
Fa�a um programa em C, utilizando uma fun��o, que eleve um n�mero inteiro qualquer a uma pot�ncia. 
O n�mero e a pot�ncia devem ser fornecidos pelo usu�rio. Imprima o resultado.
*/

//fun��o potencia��o
int potenciacao(int base, int expoente)
{
	int resultado = pow(base, expoente);
   	return resultado;
}

//fun��o Principal
int main()
{
 	setlocale(LC_ALL, "");
	int base, expoente;
	printf("Digite um n�mero para base: ");
	scanf("%d", &base);
	
	printf("Digite um n�mero para ser o expoente: ");
	scanf("%d", &expoente);
	
	printf("Resultado: %d", potenciacao(base, expoente));
 return 0;
}
