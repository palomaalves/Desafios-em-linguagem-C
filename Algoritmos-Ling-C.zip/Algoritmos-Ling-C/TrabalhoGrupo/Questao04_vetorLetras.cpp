#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 04
	Leia um vetor LETRAS de 20 letras e, depois, escreva a quantidade de vogais que existem dentro do vetor e o
	percentual de consoantes.*/


int main() 
{

 	char LETRAS[21];
 	int i;
 	float vogal, consoante, totalLetras, percentualConsoante;

   	printf("Informe a palavra: ");
	scanf(" %s", LETRAS);
    strupr(LETRAS);    

 	for ( i = 0; i < strlen(LETRAS); i++)
	{
            if ((LETRAS[i] == 'A')|| (LETRAS[i] == 'E') || (LETRAS[i] == 'I') || (LETRAS[i] == 'O') || (LETRAS[i] == 'U')) 
				{
                vogal++;
	    		}
			if ((LETRAS[i] != 'A')& (LETRAS[i] != 'E') & (LETRAS[i] != 'I') & (LETRAS[i] != 'O') & (LETRAS[i] != 'U')) 
				{
                consoante++;
	    		}
    }
      
	totalLetras=vogal+consoante;
	percentualConsoante=((consoante/totalLetras)*100);    
	printf( "\nTotal de letras %.0f %\n", totalLetras);
		
		

    printf( "\nA Palavra: %s, tem %.0f vogais, tem %.0f consoantes.\n", LETRAS, vogal,consoante);
	printf( "\nPercentual de consoantes %.2f por cento.\n", percentualConsoante);

    return 0;
}

  
 


