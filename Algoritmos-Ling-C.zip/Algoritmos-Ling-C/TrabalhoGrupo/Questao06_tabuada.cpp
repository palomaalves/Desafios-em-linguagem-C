#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*
Disciplina de T�cnicas de Programa��o
Professor Renan Alencar
Grupo 01:
Alequissandra Rayane Farias Santos Silva - 202000574
Beatriz Lira Martins - 2020002049
Matheus Barros Cris�stomo - 202058447
Paloma Corr�a Alves - 202000716
Thulio Mateus de Oliveira Queiroz - 202003804
*/

/*Quest�o 06
	Crie uma fun��o para exibir a tabuada da multiplica��o de um n�mero que deve ser passado como par�metro.
	Por exemplo, se vier o n�mero 1, voc� deve imprimir a tabuada da multiplica��o do n�mero 1 (a multiplica��o de 1
	com todos os outros n�meros de 0 a 9). Fa�a tamb�m o algoritmo principal que vai chamar essa fun��o. */

//fun��o tabuada
void tabuada(int numero)
{
	printf("Digite um n�mero para exibir a tabuada: ");
	scanf("%d", &numero);
	
	int i;
	for (i = 0; i <= 9; i = i + 1)
        {
        printf("%d x %d = %d\n", numero, i, numero * i);
        printf("\n");
        }
}

//fun��o principal
int main( )
{
	setlocale(LC_ALL, "");
	int i, numero;
   	tabuada(numero);
    return 0;
}
