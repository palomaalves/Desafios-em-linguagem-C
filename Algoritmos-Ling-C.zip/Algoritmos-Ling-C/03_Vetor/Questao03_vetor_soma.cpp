#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Construa um programa que l�, soma e imprime o resultado da soma de um vetor de inteiros de 10 posi��es
int main() 
{
	setlocale(LC_ALL, "");
	
	int vetor[10], i, soma=0;
	
	for(i=0; i<10; i++)
	{
		printf("Digite um n�mero: ");
		scanf("%d", &vetor[i]);
	}
		
	for(i=0; i<10; i++)
	{
		soma+=vetor[i];
	}
	
	printf("\n A soma dos elementos do vetor � %d\n", soma);
	
	return 0;
}
