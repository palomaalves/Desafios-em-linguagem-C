#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


//Construa um programa que preenche um vetor de inteiros de 100 n�meros, colocando 0 nas posi��es par e 1 �mpar.
int main() 
{
	setlocale(LC_ALL, "");
	
	int vetor[100];
	int i;
	
	for(i=0; i<100; i++)
	{
		if(i%2==0)
		{
			vetor[i]=0;
		}
		else
		{
			vetor[i]=1;
		}
	}	
	for(i=0; i<100; i++)
	{
		printf("Posi��o #%d: %d\n", i, vetor[i]);
	}
	return 0;
}			
