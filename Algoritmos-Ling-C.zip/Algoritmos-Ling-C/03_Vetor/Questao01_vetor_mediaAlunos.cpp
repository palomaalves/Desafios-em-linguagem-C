#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Fazer um programa que preenche um vetor de 10 posi��es contendo as notas dos alunos de uma turma.Em seguida o programa deve imprimir a media aritm�tica dos 10 alunos.
int main() 
{
	setlocale(LC_ALL, "");
	
	float notas[10];
	float soma=0, media;
	int i;
	
	for(i=0;i<10; i++)
	{
		printf("\nInsira a %da nota: \n", (i+1));
		scanf("%f", &notas[i]);
		soma=soma + notas[i];
	}
		
			
	printf("A media � %.2f ", soma/3);
	
	
	return 0;
}			
