#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Construa um programa que multiplique os valores de um vetor de reais de 20 posi��es pelo valores de um outro vetor de reais de 20 posi��es. 
//Os resultados das multiplica��es devem ser armazenados num terceiro vetor.
int main() 
{
	setlocale(LC_ALL, "");
	
	float vetor1[20], vetor2[20], resultado[20];
	int i; 
	
	for(i=0; i<20; i++)
	{
		printf("Digite o n�mero para a posi��o do vetor1[%d]: ", i+1);
		scanf("%f", &vetor1[i]);
	}
	for(i=0; i<20; i++)
	{
		printf("Digite o n�mero para a posi��o do vetor2[%d]: ", i+1);
		scanf("%f", &vetor2[i]);
	}
		
	for(i=0; i<20; i++)
	{
		resultado[i]=vetor1[i] * vetor2[i];
		printf("\n%.1f * %.1f = %.1f \n", vetor1[i], vetor2[i], resultado[i]);
	}
		
	return 0;
}
