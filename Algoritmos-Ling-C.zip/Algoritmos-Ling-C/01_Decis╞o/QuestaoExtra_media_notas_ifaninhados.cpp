#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* Altere a fun��o que l� as notas do aluno e imprime a m�dia para que a mensagem impressa se comporte da seguinte maneira:
Se a m�dia foi maior ou igual a 7.0 a mensagem deve ser �Aprovado�. Caso contr�rio a mensagem deve ser �Estude mais para a final�.*/

int main() {
	setlocale(LC_ALL,"");
	
	float n1, n2, n3, media;
	
	int qtdFaltas, totalAulas;
	
	float porcFaltas;
	
	printf("Digite a primeira nota: ");
	scanf("%f", &n1);
	fflush(stdin);
	
	printf("Digite a segunda nota: ");
	scanf("%f", &n2);
	fflush(stdin);
	
	printf("Digite a terceira nota: ");
	scanf("%f", &n3);
	fflush(stdin);
	
	media = (n1 + n2 + n3) / 3;
	
	printf("Digite a quantidade de faltas: ");
	scanf("%d", &qtdFaltas);
	fflush(stdin);
	
	printf("Digite o total de aulas dadas: ");
	scanf("%d", &totalAulas);
	
	porcFaltas = (float) qtdFaltas / totalAulas;
	
	printf("\nM�dia: %.1f", media);
	printf("\nPorcentagem de faltas: %.1f", porcFaltas * 100);
		
	if(media >= 7.0) {
		if(porcFaltas <= 0.25) {
			printf("\nAprovado por m�dia.\n");
		} else {
			printf("\nReprovado por faltas.\n");
		}
	} else {
		printf("\nEstude mais para a final.\n");
	}
	
	return 0;
	
}
