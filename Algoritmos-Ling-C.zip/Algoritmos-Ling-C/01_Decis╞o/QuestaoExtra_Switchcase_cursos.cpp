#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* Escreva uma fun��o que solicita o usu�rio digitar um numero de 1 � 7. Em seguida a fun��o imprime uma mensagem de acordo com o numero digitado:
1 ��Voc� pertence ao curso de Psicologia�
2 ��Voc� pertence ao curso de Gastronomia�
3 ��Voc� pertence ao curso de Farm�cia�
4 ��Voc� pertence ao curso de Enfermagem�
5 ��Voc� pertence ao curso de Gest�o da Tecnologia da Informa��o�
6 ��Voc� pertence ao curso de Engenharia El�trica�
7 ��Voc� pertence ao curso de Ci�ncia da Computa��o�
Qualquer outro numero -�Voc� n�o pertence a curso algum da UNIFG� */

int main() {
	setlocale(LC_ALL,"");
	int opcao;
	
	printf("Digite o c�digo do curso: ");
	scanf("%d", &opcao);
	
	switch(opcao) {
		case 1:
			printf("\nVoc� pertence ao curso de psicologia.\n");
		break;
		case 2:
			printf("\nVoc� pertence ao curso de gastronomia.\n");
		break;
		case 3:
			printf("\nVoc� pertence ao curso de f�rmacia.\n");
		break;
		case 4:
			printf("\nVoc� pertence ao curso de enfermagem.\n");
		break;
		case 5:
			printf("\nVoc� pertence ao curso de gest�o da tecnologia da informa��o.\n");
		break;
		case 6:
			printf("\nVoc� pertence ao curso de engenharia el�trica.\n");
		break;
		case 7:
			printf("\nVoc� pertence ao curso de ci�ncia da computa��o.\n");
		break;
		default:
			printf("\nVoc� pertence a curso algum da UNIFG.\n");
	}
	
	return 0;
}
