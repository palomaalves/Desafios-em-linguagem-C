#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* Escreva um programa que l� a idade de um usuario e em seguida diz se o usu�rio � ou n�o maior de idade. */

int main() {
	setlocale(LC_ALL,"");
	
	int idade;
	printf("Digite a sua idade: ");
	scanf("%d", &idade);
	
	if(idade >= 18) {
		printf("\nMaior de idade.");
	} else {
		printf("\nMenor de idade.");
	}
	
	return 0;
}
