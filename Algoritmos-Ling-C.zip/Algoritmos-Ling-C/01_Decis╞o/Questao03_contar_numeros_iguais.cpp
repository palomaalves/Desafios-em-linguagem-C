#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* Escreva um programa que l� tres numeros e em seguida imprime quantos deles s�o iguais.*/

int main() {
	setlocale(LC_ALL,"");
	
	int a, b, c, cont = 0;
	
	printf("Digite tr�s n�meros: ");
	scanf("%d %d %d", &a, &b, &c);
	
	if(a == b && b == c) {
		cont = 3;
	} else if(a == b) {
		cont = 2;
	} else if(b == c) {
		cont = 2;
	} else if(a == c) {
		cont = 2;
	}
	
//	if(a == b && b == c) {
//		cont = 3;
//	} else if(a== b || b == c || a == c) {
//		cont = 2;
//	}
	
	printf("\nQuantidade de n�meros iguais � %d", cont);
	
	
	return 0;
}
