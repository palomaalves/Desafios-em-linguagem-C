#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* Escreva um programa que l� a idade de um usuario e em seguida diz se o usu�rio � ou n�o maior de idade.*/

int main() {
	setlocale(LC_ALL,"");
	
	int num;
	printf("Digite um n�mero: ");
	scanf("%d", &num);
	
	if(num % 2 == 0) {
		printf("\n%d � par.", num);
	} else {
		printf("\n%d � impar.", num);
	}
	
	return 0;
}
