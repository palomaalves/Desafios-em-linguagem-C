#include <stdlib.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL,"");
	float n1,n2, r;
	int opcao;
    
	printf("Digite dois valores: ");
	scanf("%f %f",&n1, &n2);
	fflush(stdin);
	
	printf("\nDigite 1 para multiplica�ao");
	printf("\nDigite 2 para divisao\n");
	printf("Digite 3 para soma");
	printf("\nDigite 4 para subtra�ao\n");
	scanf("%d",&opcao);
	
	
	switch (opcao)
	{


   	case 1:
		
			r=n1*n2;
			printf("\n Resultado da multiplica�ao eh %.2f",r);
			break;
   	case 2:
			if(n2 != 0){
			r=n1/n2;
			printf("\n Resultado da divisao eh %.2f",r);
			}else{
			printf("\n Opera��o Inv�lida");
			}
			break;
	case 3:

			r=n1+n2;
			printf("\n Resultado da soma e %.2f",r);
			break;
	case 4:

			r=n1-n2;
			printf("\n Resultado da subtra�ao e %.2f",r);
			break;
    default:
           	printf("comando invalido");

	}
 
 return 0;
}
