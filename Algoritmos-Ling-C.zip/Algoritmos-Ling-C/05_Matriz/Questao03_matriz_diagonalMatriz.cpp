#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


//Dada uma matriz 5 x 5, elabore um algoritmo que escreva:
/*
a)A diagonal principal
b)A diagonal secund�ria
c)A soma da linha 4
d)A soma da coluna 2
*/

int main() 
{
	setlocale(LC_ALL, "");
	
	int matriz[3][3], diagonalP[3], diagonalS[3], somaLinha2=0, somaColuna2=0;
	// vari�veis de controle para linha e coluna das matrizes
	int i, j;
	
	// Preenchendo a matriz 
	for(i=0; i<3; i++) 
	{
		for(j = 0; j < 3; j++) 
		{
			printf("Digite um n�mero para matriz[%d][%d]: ", i, j);
			scanf("%d", &matriz[i][j]);
			fflush(stdin);
		}
	}
	// Mostrando a matriz 
	for(i =0; i<3; i++) 
	{
		for(j =0; j<3; j++) 
		{
			printf("%d\t", matriz[i][j]);
		}
		printf("\n");
	}
	
	
	//Calculando a Diagonal Principal, Diagonal Secund�ria, Soma da linha 4 e Soma da Coluna 2
	for(i=0; i<3; i++) {
		for(j=0; j<3; j++) 
		{
			if(i==j)
			{
				diagonalP[i]=matriz[i][j];
			}	
			if(i+j==2)
			{
				diagonalS[i]=matriz[i][j];
			}
			if(i==2)
			{
				somaLinha2 += matriz[i][j];
			}
			if(j==2)
			{
				somaColuna2 +=matriz[i][j];
			}
		}
	}

			
	// Imprimindo os resultados 
	printf("\nDiagonal Princiapl:\n");
	for(i=0; i<3; i++) 
	{
		printf("%d\t", diagonalP[i]);
	}
	
	printf("\nDiagonal Secund�ria:\n");
	for(i =0; i<3; i++) 
	{
		printf("%d\t", diagonalS[i]);
	}
	printf("\nSoma da Linha 2: %d\n", somaLinha2);
	printf("\nSoma da Coluna 2: %d\n", somaColuna2);
	
	return 0;
}	
