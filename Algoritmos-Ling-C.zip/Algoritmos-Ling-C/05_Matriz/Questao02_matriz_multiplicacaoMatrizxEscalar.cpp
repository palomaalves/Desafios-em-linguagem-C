#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


//Fa�a um programa que multiplica uma matriz 3 x 3 de inteiros por um escalar k = 5.
int main() 
{
	setlocale(LC_ALL, "");
	
	int matrizA[3][3], matrizR[3][3], escalar=5;
	// vari�veis de controle para linha e coluna das matrizes
	int i, j;
	
	// preenchendo a matriz A
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 3; j++) {
			printf("Digite n�mero para a posi��o A[%d][%d]: ", i + 1, j + 1);
			scanf("%d", &matrizA[i][j]);
			fflush(stdin);
		}
	}
	
	// preenchendo a matriz R realizando a multiplicacao entre a matriz A e o escalar 5
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 3; j++) {
		matrizR[i][j] = matrizA[i][j] * escalar;	
		}
	}

			
	// imprime o resultado 
	printf("\nResultado:\n\n");
	for(i = 0; i < 3; i++) {
		for(j = 0; j < 5; j++) {
			printf("%d\t", matrizR[i][j]);
		}
		printf("\n");
	}
	return 0;
}	
