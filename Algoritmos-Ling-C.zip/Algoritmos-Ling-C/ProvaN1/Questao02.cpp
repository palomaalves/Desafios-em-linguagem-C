#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

int funcao1(int xent){
	char str[10];
	int xsaida;
	
	sprintf(str, "%i", xent);
	
	strrev(str);
	
	xsaida=atoi(str);
	
	return xsaida;
}

int main(){
	printf("\n %i", funcao1(12345));
	
}
