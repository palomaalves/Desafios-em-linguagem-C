#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

int main(){
	int xent;
	char str[10];
	int xsaida;
	
	printf("Digite o valor de entrada: ");
	scanf("%i", &xent);
	sprintf(str, "%i", xent);
	
	strrev(str);
	
	xsaida=atoi(str);
	
	printf("O valor �  %i", xsaida);
	return 0;
}


