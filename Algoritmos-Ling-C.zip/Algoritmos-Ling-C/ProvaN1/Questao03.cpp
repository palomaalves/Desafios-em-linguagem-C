#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

void surpresa (int n)
{
	int a =0, b=0;
	
	while (n>0)
	{
		if((n%2)== 0)
			a=a+1;
		else
			b=b+1;
		n=n/2;	
	}
	printf("%d %d\n", a, b);
}

int main(){
	int n=44;
	
	surpresa(n);
	return 0;
}

/*Testando o 44 temos:

n: 44; 22; 11; 5,5...

a: 1; 2; 2; 2; ...

b: 0; 0; 1; 2; ...

Na quarta itera��o os valores coincidem.*/
