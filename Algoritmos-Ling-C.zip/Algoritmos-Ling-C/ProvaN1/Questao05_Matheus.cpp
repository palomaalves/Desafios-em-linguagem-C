#include <stdio.h>
#include <stdlib.h>
#include <locale.h>



int main() 
{
	setlocale(LC_ALL, "");
	
	int mat[3][3];
	// vari�veis de controle para linha e coluna das matrizes
	int i, j;
	
	// Preenchendo a matriz 
	for(i=0; i<3; i++) 
	{
		for(j = 0; j < 3; j++) 
		{
			printf("Digite um n�mero para matriz[%d][%d]: ", i, j);
			scanf("%d", &mat[i][j]);
			fflush(stdin);
		}
	}
	// Mostrando a matriz 
	for(i =0; i<3; i++) 
	{
		for(j =0; j<3; j++) 
		{
			printf("%d\t", mat[i][j]);
		}
		printf("\n");
	}
	
	
	//Calculando o menor valor
	
	int menor = mat[0][0];
	for(i=0; i<3; i++) 
	{
		for(j=0; j<3; j++) 
		{	
				
			if (menor > mat[i][j])
			{
				menor =  mat[i][j];
			}
		}	
	}
	

			
	// Imprimindo o resultado
	printf("\n Menor Valor:\n");
	
	printf("%d", menor);
	
	return 0;
}	
