#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Aluna: Paloma Corr�a Alves
//Fa�a um programa que leia uma matriz mat 4 x 4 e 
//imprima na tela o produto de todos os elementos diferentes de zero que comp�em a diagonal principal desta matriz mat.

//Dada uma matriz 4 x 4, elabore um algoritmo que escreva:
/*
a)A diagonal principal
b)O produto de todos os elementos diferentes de zero que comp�em a diagonal principal
*/

int main() 
{
	setlocale(LC_ALL, "");
	
	int mat[4][4], diagonalP[4], produtoDiagonal=1;
	// vari�veis de controle para linha e coluna das matrizes
	int i, j;
	
	// Preenchendo a matriz 
	for(i=0; i<4; i++) 
	{
		for(j = 0; j < 4; j++) 
		{
			printf("Digite um n�mero para matriz[%d][%d]: ", i, j);
			scanf("%d", &mat[i][j]);
			fflush(stdin);
		}
	}
	// Mostrando a matriz 
	for(i =0; i<4; i++) 
	{
		for(j =0; j<4; j++) 
		{
			printf("%d\t", mat[i][j]);
		}
		printf("\n");
	}
	
	
	//Calculando a Diagonal Principal e o Produto de todos os elementos diferentes de zero que comp�em a diagonal principal
	for(i=0; i<4; i++) 
	{
		for(j=0; j<4; j++) 
		{
			if(i==j)
			{
				diagonalP[i]=mat[i][j];
			}
		}
	}		
	
	for(i=0; i<4; i++) 
	{
			
		if(diagonalP[i]!=0)
			{
				produtoDiagonal *= diagonalP[i];
			}
		
	}
	

			
	// Imprimindo os resultados 
	printf("\nDiagonal Principal:\n");
	for(i=0; i<4; i++) 
	{
		printf("%d\t", diagonalP[i]);
	}
	
	printf("\nProduto da Diagonal Principal %d\n", produtoDiagonal);
	
	
	return 0;
}	
