#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Fa�a um programa que solicita o usu�rio digitar o nome e endere�o completo (armazenando em duas strings).
//Em seguida o programa imprime na tela o que foi digitado.

int main() 
{
	setlocale(LC_ALL, "");
	
	char nome[50];
	char endereco[100];
	
	printf("Digite seu Nome Completo: ");
	//gets(nome);
	fgets(nome, 50,stdin);
	
	fflush(stdin);
	
	printf("Digite seu Endere�o Completo: ");
	//gets(endereco);
	fgets(endereco, 100, stdin);
	
	printf("\nNome Completo: %s ", nome);
	printf("\nEndere�o Completo: %s", endereco);
	
	return 0;
}
