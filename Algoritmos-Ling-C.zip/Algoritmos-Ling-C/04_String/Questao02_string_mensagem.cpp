#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

//Faca um programa que solicita o usu�rio digitar uma mensagem (string).
//Em seguida o programa converte todos os caracteres da string para mai�sculo e depois imprime os resultados.

int main() 
{
	setlocale(LC_ALL, "");
	
	char mensagem[100];
	
	printf("Digite uma mensagem: ");
	//gets(mensagem);
	fgets(mensagem, 100,stdin);
	
	fflush(stdin);
	
	printf("\nA mensagem digitada foi: %s ", mensagem);

	strupr(mensagem);
	
	printf("\nA mensagem agora est� assim: \n%s", mensagem);
	return 0;
}
