#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

/*1.
1-Fa�a um programa que solicita o usu�rio digitar o nome e sobrenome
2.Em seguida o programa solicita o usu�rio digitar rua, numero, bairro, cidade (capturando todos os dados como string).
3.Finalmente o programa concatena o nome e sobrenome e mostra na tela.
4.Depois o programa concatena os dados do endere�o e imprime o endere�o de uma s� vez.*/

int main() 
{
	setlocale(LC_ALL, "");
	char nome[20], sobrenome[20];
	char rua[30], numero[8], bairro[30], cidade[30];
	
	printf("Digite seu nome: ");
	fgets(nome, 20, stdin);
	printf("Digite seu sobrenome: ");
	fgets(sobrenome, 20, stdin);
	printf("Digite o n�mero da sua casa: ");
	fgets(numero, 8, stdin);
	printf("Digite a sua rua: ");
	fgets(rua, 30, stdin);
	printf("Digite o seu bairro: ");
	fgets(bairro, 30, stdin);
	printf("Digite sua cidade: ");
	fgets(cidade, 30, stdin);
	system("CLS");
	
	//junta as strings
	strncat(nome, sobrenome, 40);
	strncat(numero, rua, 40);
	strncat(bairro, cidade, 40);
	
	//imprime as strings
	printf("\nSeu nome completo �: %s", nome);
	printf("\nSeu endere�o �: %s", numero);
	printf("\nSeu bairro e cidade s�o: %s\n\n", bairro);
	system("pause");
}

