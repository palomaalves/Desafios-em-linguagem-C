#include <stdlib.h>
#include <stdlib.h>
#include <locale.h>


//Escreva um programa que calcula o produto de dois n�meros lidos sem usar o operador de multiplica��o (�*�).

int main()
{
    setlocale(LC_ALL,"");
	int n1,n2, resultado;
	int contador=0;
	
	printf("\nDigite as dois n�meros:");	
    scanf("\n %d %d", &n1, &n2);
    	
    resultado= 0;	
    
	while(contador < n2){
    	resultado=resultado+n1;    	
    	contador++;
	}
	printf("\n O resultado de %d * %d = %d", n1, n2, resultado);
	return 0;
}
