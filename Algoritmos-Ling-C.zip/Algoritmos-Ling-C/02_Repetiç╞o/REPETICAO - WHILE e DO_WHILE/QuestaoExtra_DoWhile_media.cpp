#include <stdlib.h>
#include <stdlib.h>
#include <locale.h>


//Como ficaria o algoritmo para calcular a m�dia dos 5 alunos com teste no final usando o comando do-while?
int main() 
{
	setlocale(LC_ALL, "");
	
	float n1, n2, media;
	int contador = 0;
	
	 do
	 {
	 	printf("\nDigite as duas notas: \n");
		scanf("%f %f", &n1, &n2);		
		media = (n1 + n2) / 2;
	 	printf("\nM�dia: %.1f\n", media);
		contador++; 
	 }while(contador < 5); 
		
return 0;
}
