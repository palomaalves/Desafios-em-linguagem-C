#include <stdlib.h>
#include <stdlib.h>
#include <locale.h>

/*Como seria um programa para calcular a m�dia de 5 alunos da uma turma?*/

int main()
{
    setlocale(LC_ALL,"");
	float n1,n2, media;
	int contador=0;
	
    while(contador < 5){
    	printf("\nDigite as duas notas:");	
    	scanf("%f %f", &n1, &n2);
    	media=(n1+n2)/2;
    	printf("\n A m�dia foi %.1f \n", media);
    	
    	contador++;
	}
	
		
return 0;
}	
