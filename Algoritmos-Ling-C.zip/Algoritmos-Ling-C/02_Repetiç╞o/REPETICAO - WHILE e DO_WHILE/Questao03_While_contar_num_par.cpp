#include <stdlib.h>
#include <stdlib.h>
#include <locale.h>


//Construa um algoritmo que fica lendo indefinidamente n�meros positivos. 
//Caso o numero lido seja igual a 0 o algoritmo p�ra de ler n�meros e imprime a m�dia dos n�meros pares lidos anteriormente.
int main()
{
    setlocale(LC_ALL,"");
	int num, somaPar=0;
	int contadorPar=0;
	float media;
	
	//media = soma dos n�meros pares (somaPar) / quantidade  de n�meros pares; 
	
	printf("\nDigite um n�mero inteiro positivo:");	
    scanf("\n %d", &num);
    printf("\nN�mero digitado: %d, somaPar: %d, contadorPar: %d", num, somaPar, contadorPar);		
   	
	while(num == 0)
	{
    	if(num % 2 == 0)
		{
	    	somaPar = somaPar +num;
			contadorPar++;	
		}
		printf("\nDigite um n�mero inteiro positivo:");	
	    scanf("\n %d", &num);
	}
		
	media =(float) somaPar/ contadorPar;
    printf("\n M�dia dos n�meros pares digitados %.1f", media);
	return 0;
}
