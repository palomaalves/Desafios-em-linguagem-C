#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Escreva um algoritmo que l� 5 n�meros inteiros e em seguida mostra a soma de todos os �mpares lidos.
int main() 
{
	setlocale(LC_ALL, "");
	
	int numero, somaImpar=0;
	int contadorImpar;
	
	for(contadorImpar=0 ;contadorImpar<5; contadorImpar++)
	{
		printf("\nInsira um numero: \n");
		scanf("%d", &numero);
		if(numero % 2 != 0)
		{
			somaImpar = somaImpar + numero;
		}
	}
	printf("A soma dos n�meros �mpares �: %d", somaImpar);
	
	return 0;
}	


