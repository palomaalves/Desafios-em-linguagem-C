#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Altere o algoritmo anterior para que ele considere apenas a soma dos �mpares que estejam entre 100 e 200.
int main() 
{
	setlocale(LC_ALL, "");
		
	int numero, somaImpar=0;
	int contadorImpar;
	
	for(contadorImpar=0 ;contadorImpar<5; contadorImpar++)
	{
		printf("\nInsira um numero: \n");
		scanf("%d", &numero);
		if(numero % 2 != 0 && (numero>=100 && numero<=200))
		{
			somaImpar = somaImpar + numero;
		}
	}
	printf("A soma dos n�meros �mpares �: %d", somaImpar);
	
	return 0;
}
