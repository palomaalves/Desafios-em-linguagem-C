#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Como ficaria o algoritmo para calcular a media dos 5 alunos usando repeticao fixa?

int main() 
{
	setlocale(LC_ALL, "");
	
	float n1, n2, media;
	int contador;
	
	for(contador=0 ;contador < 5; contador++){
		printf("\nInsira nota 1 e nota 2: \n");
		scanf("%f %f", &n1, &n2);
		media =(n1 + n2)/2;
		printf("\nA m�dia �: %.1f", media);
	}
	
	
return 0;
}	
	
