#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


//Construa um algoritmo que leia um conjunto de 20 numeros inteiros e mostre qual foi o maior e o menor valor fornecido.
int main() 
{
	setlocale(LC_ALL, "");
	
	int numero=0, maior=0, menor=0;
	int contador;
	
	for(contador=0;contador<5; contador++)
	{
		printf("\nInsira um numero: \n");
		scanf("%d", &numero);
		if(contador==0)
		{
			maior=numero;
			menor=numero;
		}
		else if(numero>maior)
		{
			maior=numero;
		}else if(numero<menor)
		{
			menor=numero;	
		}
	}
	printf("Maior: %d e Menor: %d", maior, menor);
	
	
	return 0;
}
