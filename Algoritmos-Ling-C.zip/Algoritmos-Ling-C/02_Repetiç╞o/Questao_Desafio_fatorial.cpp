#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//Escreva um programa que l� um n�mero e em seguida calcula e imprime seu fatorial.

int main() 
{
	setlocale(LC_ALL, "");
	int numero, fatorial;

	printf("\nInsira um numero: \n");
	scanf("%d", &numero);
	for(fatorial=1; numero>1; numero--)
	{
		fatorial*=numero;
	}
	printf("\nO Fatorial � igual a %d", fatorial);
	return 0;	
}
