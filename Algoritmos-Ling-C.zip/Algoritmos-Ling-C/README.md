# Algoritmos Ling C C++
 Repositório dos Exercícios da Disciplaina Algoritmos e Programação em Linguagem C/C++

 Projetos da Disciplina Algoritmos e Programação em C/C++. A disciplina apresentou os conceitos fundamentais da lógica aplicada à programação de computadores e resolução de problemas por meio de métodos e técnicas computacionais. Teve como objetivos:

1.Desenvolver a lógica de programação através de uma linguagem de programação estruturada; 
2.Interpretar textos para identificar os componentes básicos visando a criação de uma solução; 
3.Escolher a melhor estrutura e o melhor algoritmo para solução de um determinado problema; 
4.Conceituar variável, estrutura de decisão, estrutura de repetição, vetor e matriz no contexto de algoritmos;
5.Avaliar algoritmos utilizando teste de mesa; 
6.Implementar algoritmos simples utilizando linguagem de programação C/C++..

Exercicíos com: 1- Estrutura de Variáveis e Operações. 2- Estrutura de Decisão. 3- Estrutura de Seleção Switch. 4- Estrutura Condicionais. 5- Estruturas de Repetição While e For. 6- Vetores 7- Matrizes
