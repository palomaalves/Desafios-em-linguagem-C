#include <conio.h> 
#include <stdio.h> 

//O que faz o seguinte programa quando executado?

void programaA() {
	int vet[] = {4,9,12}; 
	int i;
	int *ptr;
	ptr = vet;
	
	printf("\n ");
	for(i = 0 ; i < 3 ; i++) 
	{ 
		printf("%d ",*ptr++);
	}
	printf("\n ");
}
	
void programaB() {
	int vet[] = {4,9,12}; 
	int i;
	int *ptr;
	ptr = vet;
	
	printf("\n ");	
	for(i = 0 ; i < 3 ; i++) 
	{ 	
		printf("%d ",(*ptr)++);
	}
}

void programaC() {
	int vet[] = {4,9,12}; 
	int i;
	int *ptr;
	ptr = vet;
	
	printf("\n ");	
	for(i = 0 ; i < 3 ; i++) 
	{ 	
		printf("%d ",++(*ptr));
	}

	}	

int main()
{
	programaA();
	programaB();
	programaC();


	
	return(0);

}

