#include <conio.h> 
#include <stdio.h> 
#include <string.h>

//7. Fa�a um programa que l� uma vetor com 05 elementos e imprime apenas os valores pares. A fun��o que executa tal tarefa deve ter o seguinte prot�tipo:
//void vetorpares (int *p);

#define TAM 5

void vetorpares(int *p);

int main() {
	int vetor[TAM]; 
	int i;
	
	for(i=0; i<TAM; i++)
	{
		printf("Digite um n�mero: ");
		scanf("%d", &vetor[i]);
		fflush(stdin);
	}
	vetorpares(vetor);
	
	return(0);
}

void vetorpares(int *p){
	int i; 
	for(i=0; i<TAM; i++){
		if(p[i]% 2==0){
			printf("\n%d", p[i]);
		}	
		
	}

}
