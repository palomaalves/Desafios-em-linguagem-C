#include <conio.h> 
#include <stdio.h>

//4. O que fazem os seguintes programas?
 
int main(){

	int vet[] = {4,9,13};
	int i;
	
	for(i=0;i<3;i++){
	int i;
	
	printf("\n%d",*(vet+i));
	printf("\n%X ",vet+i);
	printf("\n%X ",vet+i);
	}
	
	return(0);

}

