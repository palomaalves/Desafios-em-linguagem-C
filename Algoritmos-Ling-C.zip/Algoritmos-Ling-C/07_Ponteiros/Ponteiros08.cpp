#include <conio.h> 
#include <stdio.h> 

//8. Fa�a um programa que l� duas matrizes 2x2 e imprime a sua soma. A fun��o deve ter o seguinte prot�tipo:
//void somamatriz (int *p);


void somamatriz(int *p, int *q);
int main() {
	int mat1[2][2];
	int mat2 [2][2];
	int i, j;
	
	for(i=0; i<2;i++){
		for(j=0; j<2;j++){
			printf("Digite um n�mero para a mat1[%d][%d]",i, j);
			scanf("%d", &mat1[i][j]);
		}
	}
	for(i=0; i<2;i++){
		for(j=0; j<2;j++){
			printf("Digite um n�mero para a mat2[%d][%d]",i, j);
			scanf("%d", &mat2[i][j]);
		}
	}
	
	
	return(0);
}

void somamatriz(int *p, int *q){
	int i, j;
	for(i=0; i<2;i++){
		for(j=0; j<2;j++){
			printf("%d\t", *(p+i+j)+ *(q+i+j));
			printf("%d\t", (*(p)[i][j]+ *(q)[i][j])); ERRO
		}
	}
}
