#include <conio.h> 
#include <stdio.h> 
#include <string.h>

//6. Fa�a um programa que l� uma string e imprime a sua inversa. O prot�tipo da fun��o deve ser:
//void inverte(char *str);

void inverte(char *str);

int main() {
	char nome[10]; 
	printf("Digite um nome: ");
	fgets(nome, 10, stdin);
	
	printf("\nO Nome digitado foi: %s\n", nome);
	
	inverte(nome);
	printf("\nO Nome invertido: %s\n", nome);
	
	return(0);
}
	
void inverte(char *str){
	
	strrev(str);
}	

